# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['cmapingest']

package_data = \
{'': ['*']}

install_requires = \
['Ipython>=7,<8',
 'Pillow==7.2.0',
 'beautifulsoup4==4.9.1',
 'folium==0.11.0',
 'numpy==1.19.0',
 'pandas>=1.0.5,<2.0.0',
 'pycmap==0.1.8',
 'pyodbc>=4.0,<5.0',
 'requests==2.24.0',
 'selenium==3.141.0']

setup_kwargs = {
    'name': 'cmapingest',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Norland Raphael Hagen',
    'author_email': 'norlandrhagen@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
