"""
Modified pycmap script
"""
"""
Author: Mohammad Dehghani Ashkezari <mdehghan@uw.edu>

Date: 2019-04-15

Function: Create a geospatial heatmap of sparse variables within a predefined space-time domain.
"""
